﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Diagnostics;
using SourceCode.Workflow.Client;
using SourceCode.Hosting.Client.BaseAPI;
using System.Text.RegularExpressions;
using System.Web;

namespace InObitsProjectManagementExtension
{
    public class InObitsProjectManagementExtension
    {
        #region General E-Mail Helper
        public static string EMailHTMLData(string MilestoneId, string ParticipantName, string NotificationType,
            string TaskURL = null
            )
        {
            string templatePath = GetAppConfigEmailTemplatePath();
            string HTMLData = string.Empty;
            string connectionString = GetAppConfigSQLConnectionString();
            templatePath = templatePath + NotificationType + ".html";

            StreamReader sr = new StreamReader(templatePath.ToLower());
            HTMLData = sr.ReadToEnd();
            sr.Close();

            HTMLData = HTMLData.Replace("{ParticipantName}", ParticipantName);
            HTMLData = HTMLData.Replace("{WorklistURL}", TaskURL);

            using (var connection = new SqlConnection(connectionString))
            {
                var usp_EmailMetaDataGenerator = new SqlCommand("ProjectManagementEmailGenerator", connection);
                usp_EmailMetaDataGenerator.CommandType = CommandType.StoredProcedure;
                usp_EmailMetaDataGenerator.Parameters.Clear();


                usp_EmailMetaDataGenerator.Parameters.AddWithValue("@MilestoneId", MilestoneId);


                connection.Open();
                using (var reader = usp_EmailMetaDataGenerator.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Filling the placeholders


                        HTMLData = HTMLData.Replace("{ProjectName}", reader["ProjectName"].ToString());
                        HTMLData = HTMLData.Replace("{MilestoneStartDate}", reader["MilestoneStartDate"].ToString());
                        HTMLData = HTMLData.Replace("{MilestoneEndDate}", reader["MilestoneEndDate"].ToString());
                        HTMLData = HTMLData.Replace("{MilestoneName}", reader["MilestoneName"].ToString());
                        HTMLData = HTMLData.Replace("{Owner}", reader["Owner"].ToString());
                        HTMLData = HTMLData.Replace("{ServiceType}", reader["ServiceType"].ToString());
                        HTMLData = HTMLData.Replace("{AssignedDays}", reader["AssignedDays"].ToString());
                        HTMLData = HTMLData.Replace("{PrimaryResourceDisplayName}", reader["PrimaryResourceDisplayName"].ToString());
                    }
                }
            }

            return HTMLData;
        }
        #endregion

        #region Plan E-Mail Helper
        public static string PlanEmailHTMLData(string PlanId, string MilestoneId, string ParticipantName, string NotificationType,
            string TaskURL = null
            )
        {
            string templatePath = GetAppConfigPlanEmailTemplatePath();
            string HTMLData = string.Empty;
            string connectionString = GetAppConfigSQLConnectionString();
            templatePath = templatePath + NotificationType + ".html";

            StreamReader sr = new StreamReader(templatePath.ToLower());
            HTMLData = sr.ReadToEnd();
            sr.Close();

            HTMLData = HTMLData.Replace("{ParticipantName}", ParticipantName);
            HTMLData = HTMLData.Replace("{WorklistURL}", TaskURL);

            using (var connection = new SqlConnection(connectionString))
            {
                var usp_PlanEmailMetaDataGenerator = new SqlCommand("ProjectManagementPlanEmailGenerator", connection);
                usp_PlanEmailMetaDataGenerator.CommandType = CommandType.StoredProcedure;
                usp_PlanEmailMetaDataGenerator.Parameters.Clear();

                usp_PlanEmailMetaDataGenerator.Parameters.AddWithValue("@PlanTimeId", PlanId);
                usp_PlanEmailMetaDataGenerator.Parameters.AddWithValue("@MilestoneId", MilestoneId);


                connection.Open();
                using (var reader = usp_PlanEmailMetaDataGenerator.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Filling the placeholders


                        HTMLData = HTMLData.Replace("{ProjectName}", reader["ProjectName"].ToString());
                        HTMLData = HTMLData.Replace("{PlanName}", reader["PlanName"].ToString());

                        // Format PlanStartDate                            
                        string formattedPlanStartDate = reader["PlanStartDate"].ToString();
                        if (!String.IsNullOrEmpty(formattedPlanStartDate))
                        {
                            DateTime PlanStartDate;
                            string format = "dd MMM yyyy";
                            DateTime.TryParse(formattedPlanStartDate, out PlanStartDate);
                            formattedPlanStartDate = PlanStartDate.ToString(format);
                        }


                        // Format PlanStartDate                            
                        string formattedPlanEndDate = reader["PlanEndDate"].ToString();
                        if (!String.IsNullOrEmpty(formattedPlanEndDate))
                        {
                            DateTime PlanEndDate;
                            string format = "dd MMM yyyy";
                            DateTime.TryParse(formattedPlanEndDate, out PlanEndDate);
                            formattedPlanEndDate = PlanEndDate.ToString(format);
                        }
                        // Format PlanStartDate                            
                        string formattedMilestone1EndDate = reader["MilestoneEndDate"].ToString();
                        if (!String.IsNullOrEmpty(formattedMilestone1EndDate))
                        {
                            DateTime MilestoneEndDate;
                            string format = "dd MMM yyyy";
                            DateTime.TryParse(formattedMilestone1EndDate, out MilestoneEndDate);
                            formattedMilestone1EndDate = MilestoneEndDate.ToString(format);
                        }
                        // Format PlanStartDate                            
                        string formattedMilestoneStartDate = reader["MilestoneStartDate"].ToString();
                        if (!String.IsNullOrEmpty(formattedMilestoneStartDate))
                        {
                            DateTime MilestoneStartDate;
                            string format = "dd MMM yyyy";
                            DateTime.TryParse(formattedMilestoneStartDate, out MilestoneStartDate);
                            formattedMilestoneStartDate = MilestoneStartDate.ToString(format);
                        }
                        


                        HTMLData = HTMLData.Replace("{PlanStartDate}", formattedPlanStartDate);
                        HTMLData = HTMLData.Replace("{PlanEndDate}", formattedPlanEndDate);
                        HTMLData = HTMLData.Replace("{PlannedDays}", reader["PlannedDays"].ToString());
                        HTMLData = HTMLData.Replace("{PlanName}", reader["PlanName"].ToString());
                        HTMLData = HTMLData.Replace("{Owner}", reader["OwnerDisplayName"].ToString());
                        HTMLData = HTMLData.Replace("{MilestoneStartDate}", formattedMilestoneStartDate);
                        HTMLData = HTMLData.Replace("{MilestoneEndDate}", formattedMilestone1EndDate);
                        HTMLData = HTMLData.Replace("{MilestoneName}", reader["MilestoneName"].ToString());
                        HTMLData = HTMLData.Replace("{EstimatedsDays}", reader["MilestoneAssignedDays"].ToString());
                        
                        
                        HTMLData = HTMLData.Replace("{ServiceType}", reader["ServiceType"].ToString());
                        HTMLData = HTMLData.Replace("{AssignedDays}", reader["MilestoneAssignedDays"].ToString());
                        HTMLData = HTMLData.Replace("{PlanResourceDisplayName}", reader["PlanResourceDisplayName"].ToString());
                        HTMLData = HTMLData.Replace("{PrimaryResourceDisplayName}", reader["PrimaryResourceDisplayName"].ToString());






                    }
                }
            }

            return HTMLData;
        }
#endregion

        #region General E-Mail Helper
        public static string TimesheetEMailHTMLData(string Id, string ParticipantName, string NotificationType, string type = "",
            string TaskURL = null
            )
        {
            string templatePath = GetAppConfigEmailTemplatePath();
            string HTMLData = string.Empty;
            string connectionString = GetAppConfigSQLConnectionString();
            templatePath = templatePath + NotificationType + ".html";

            StreamReader sr = new StreamReader(templatePath.ToLower());
            HTMLData = sr.ReadToEnd();
            sr.Close();

            HTMLData = HTMLData.Replace("{ParticipantName}", ParticipantName);
            HTMLData = HTMLData.Replace("{WorklistURL}", TaskURL);

            using (var connection = new SqlConnection(connectionString))
            {
                if (type == "Timesheet" || type == "")//default condition
                {
                    var usp_EmailMetaDataGenerator = new SqlCommand("GetTimesheetLogDetailsByID", connection);
                    usp_EmailMetaDataGenerator.CommandType = CommandType.StoredProcedure;
                    usp_EmailMetaDataGenerator.Parameters.Clear();


                    usp_EmailMetaDataGenerator.Parameters.AddWithValue("@Id", Id);


                    connection.Open();
                    using (var reader = usp_EmailMetaDataGenerator.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Filling the placeholders


                            HTMLData = HTMLData.Replace("{ProjectName}", reader["ProjectName"].ToString());
                            HTMLData = HTMLData.Replace("{Date_Approved}", reader["Date_Approved"].ToString());
                            HTMLData = HTMLData.Replace("{SubmittedByDisplayName}", reader["SubmittedByDisplayName"].ToString());
                            HTMLData = HTMLData.Replace("{MilestoneName}", reader["MilestoneName"].ToString());

                            // Format PlanStartDate                            
                            string formattedFromDate = reader["FromDate"].ToString();
                            if (!String.IsNullOrEmpty(formattedFromDate))
                            {
                                DateTime FromDate;
                                string format = "dd MMM yyyy";
                                DateTime.TryParse(formattedFromDate, out FromDate);
                                formattedFromDate = FromDate.ToString(format);
                            }


                            

                            // Format PlanStartDate                            
                            string formattedToDate = reader["ToDate"].ToString();
                            if (!String.IsNullOrEmpty(formattedToDate))
                            {
                                DateTime ToDate;
                                string format = "dd MMM yyyy";
                                DateTime.TryParse(formattedToDate, out ToDate);
                                formattedToDate = ToDate.ToString(format);
                            }

                            // Format PlanStartDate                            
                            string formattedDate_Submitted = reader["Date_Submitted"].ToString();
                            if (!String.IsNullOrEmpty(formattedDate_Submitted))
                            {
                                DateTime Date_Submitted;
                                string format = "dd MMM yyyy";
                                DateTime.TryParse(formattedDate_Submitted, out Date_Submitted);
                                formattedDate_Submitted = Date_Submitted.ToString(format);
                            }

                            HTMLData = HTMLData.Replace("{FromDate}", formattedFromDate);
                            HTMLData = HTMLData.Replace("{ToDate}", formattedToDate);
                            HTMLData = HTMLData.Replace("{Hours}", reader["Hours"].ToString());
                            HTMLData = HTMLData.Replace("{Date_Submitted}", formattedDate_Submitted);
                            HTMLData = HTMLData.Replace("{TimesheetLogStatus}", reader["TimesheetLogStatus"].ToString());
                            
                            HTMLData = HTMLData.Replace("{ApprovedByDisplayName}", reader["ApprovedByDisplayName"].ToString());
                            HTMLData = HTMLData.Replace("{LoggedEstimate}", reader["LoggedEstimate"].ToString());
                        }
                    }
                }
                else if (type == "Project")
                {
                    var usp_EmailMetaDataGenerator = new SqlCommand("GetProjectDetailsbyID", connection);
                    usp_EmailMetaDataGenerator.CommandType = CommandType.StoredProcedure;
                    usp_EmailMetaDataGenerator.Parameters.Clear();


                    usp_EmailMetaDataGenerator.Parameters.AddWithValue("@ProjectId", Id);


                    connection.Open();
                    using (var reader = usp_EmailMetaDataGenerator.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Filling the placeholders


                            HTMLData = HTMLData.Replace("{ProjectName}", reader["ProjectName"].ToString());
                            HTMLData = HTMLData.Replace("{ServiceType}", reader["ServiceType"].ToString());
                            HTMLData = HTMLData.Replace("{ProjectValue}", reader["ProjectValue"].ToString());
                            HTMLData = HTMLData.Replace("{Owner}", reader["OwnerDisplayName"].ToString());
                            HTMLData = HTMLData.Replace("{DaysSold}", reader["DaysSold"].ToString());

                        }
                    }

                }
                else if (type == "Milestone")
                {
                    var usp_EmailMetaDataGenerator = new SqlCommand("ProjectManagementEmailGenerator", connection);
                    usp_EmailMetaDataGenerator.CommandType = CommandType.StoredProcedure;
                    usp_EmailMetaDataGenerator.Parameters.Clear();


                    usp_EmailMetaDataGenerator.Parameters.AddWithValue("@MilestoneId", Id);


                    connection.Open();
                    using (var reader = usp_EmailMetaDataGenerator.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Filling the placeholders
                            // Format PlanStartDate                            
                            string formattedMilestoneStartDate = reader["MilestoneStartDate"].ToString();
                            if (!String.IsNullOrEmpty(formattedMilestoneStartDate))
                            {
                                DateTime MilestoneStartDate;
                                string format = "dd MMM yyyy";
                                DateTime.TryParse(formattedMilestoneStartDate, out MilestoneStartDate);
                                formattedMilestoneStartDate = MilestoneStartDate.ToString(format);
                            }
                            // Filling the placeholders
                            // Format PlanStartDate                            
                            string formattedMilestoneEndDate = reader["MilestoneEndDate"].ToString();
                            if (!String.IsNullOrEmpty(formattedMilestoneEndDate))
                            {
                                DateTime MilestoneEndDate;
                                string format = "dd MMM yyyy";
                                DateTime.TryParse(formattedMilestoneEndDate, out MilestoneEndDate);
                                formattedMilestoneEndDate = MilestoneEndDate.ToString(format);
                            }


                            HTMLData = HTMLData.Replace("{ProjectName}", reader["ProjectName"].ToString());
                            HTMLData = HTMLData.Replace("{MilestoneName}", reader["MilestoneName"].ToString());
                            HTMLData = HTMLData.Replace("{MilestoneStartDate}", formattedMilestoneStartDate);
                            HTMLData = HTMLData.Replace("{MilestoneEndDate}", formattedMilestoneEndDate);
                            HTMLData = HTMLData.Replace("{PrimaryResourceName}", reader["PrimaryResourceDisplayName"].ToString());
                            HTMLData = HTMLData.Replace("{ServiceType}", reader["ServiceType"].ToString());
                            HTMLData = HTMLData.Replace("{ProjectValue}", reader["ProjectValue"].ToString());
                            HTMLData = HTMLData.Replace("{Owner}", reader["OwnerDisplayName"].ToString());
                            HTMLData = HTMLData.Replace("{EstimatedDays}", reader["AssignedDays"].ToString());
                        }
                    }
                }

            }

            return HTMLData;
        }
        #endregion


        #region Leave E-Mail Helper
        public static string LeaveEMailHTMLData(string instanceId, string ParticipantName, string NotificationType, string status,
            string TaskURL = null
            )
        {
            string templatePath = GetAppConfigLeaveEmailTemplatePath();
            string HTMLData = string.Empty;
            string connectionString = GetAppConfigLeaveSQLConnectionString();
            templatePath = templatePath + NotificationType + ".html";

            StreamReader sr = new StreamReader(templatePath.ToLower());
            HTMLData = sr.ReadToEnd();
            sr.Close();

            HTMLData = HTMLData.Replace("{ParticipantName}", ParticipantName);

            using (var connection = new SqlConnection(connectionString))
            {
                var usp_LeaveEmailMetadata = new SqlCommand("usp_LeaveEmailMetadata", connection);
                usp_LeaveEmailMetadata.CommandType = CommandType.StoredProcedure;
                usp_LeaveEmailMetadata.Parameters.Clear();


                usp_LeaveEmailMetadata.Parameters.AddWithValue("@InstanceID", instanceId);
                usp_LeaveEmailMetadata.Parameters.AddWithValue("@Status", status);



                connection.Open();
                using (var reader = usp_LeaveEmailMetadata.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Filling the placeholders
                        HTMLData = HTMLData.Replace("{Title}", reader["Title"].ToString());
                        HTMLData = HTMLData.Replace("{StartDate}", reader["StartDate"].ToString());
                        HTMLData = HTMLData.Replace("{EndDate}", reader["EndDate"].ToString());
                        HTMLData = HTMLData.Replace("{Motivation}", reader["Motivation"].ToString());
                        HTMLData = HTMLData.Replace("{Status}", reader["Status"].ToString());
                        HTMLData = HTMLData.Replace("{InstanceID}", reader["InstanceID"].ToString());
                        HTMLData = HTMLData.Replace("{RefNo}", reader["ApplicationReference"].ToString());

                    }
                }
            }

            return HTMLData;
        }
        #endregion

        #region Expense E-Mail Helper
        public static string ExpenseEMailHTMLData(string Id, string ParticipantName, string NotificationType, string status,
            string TaskURL = null, string folio = null
            )
        {
            string templatePath = GetAppConfigExpenseEmailTemplatePath();
            string HTMLData = string.Empty;
            string connectionString = GetAppConfigExpenseSQLConnectionString();
            templatePath = templatePath + NotificationType + ".html";

            StreamReader sr = new StreamReader(templatePath.ToLower());
            HTMLData = sr.ReadToEnd();
            sr.Close();

            HTMLData = HTMLData.Replace("{ParticipantName}", ParticipantName);

            using (var connection = new SqlConnection(connectionString))
            {
                var usp_ExpenseEmailMetadata = new SqlCommand("usp_ExpenseClaimEmailMetadata", connection);
                usp_ExpenseEmailMetadata.CommandType = CommandType.StoredProcedure;
                usp_ExpenseEmailMetadata.Parameters.Clear();


                usp_ExpenseEmailMetadata.Parameters.AddWithValue("@Id", Id);




                connection.Open();
                using (var reader = usp_ExpenseEmailMetadata.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Filling the placeholders


                        HTMLData = HTMLData.Replace("{Claim_Year}", reader["Claim_Year"].ToString());
                        HTMLData = HTMLData.Replace("{Claim_Username}", reader["Claim_Username"].ToString());

                        HTMLData = HTMLData.Replace("{Status}", reader["Status"].ToString());
                        HTMLData = HTMLData.Replace("{Final_Claim_Amount}", reader["Final_Claim_Amount"].ToString());
                        HTMLData = HTMLData.Replace("{RefNo}", folio);
                        HTMLData = HTMLData.Replace("{WorkListURL}", TaskURL);
                        HTMLData = HTMLData.Replace("{Claim_Month}", System.Globalization.DateTimeFormatInfo.CurrentInfo.GetAbbreviatedMonthName(Convert.ToInt32(reader["Claim_Month"].ToString())));

                    }
                }
            }

            return HTMLData;
        }
        #endregion

        #region E-Mail Helper - Get Pending Tasks
        public static string GetPendingTasksEmailHTML(string ParticipateUserName, string ParticipateUserDisplayName, string NotificationType

            )
        {
            //Building an HTML string.
            StringBuilder tasklisthtml = new StringBuilder();

            string templatePath = GetAppConfigTaskEmailTemplatePath();
            string HTMLData = string.Empty;
            templatePath = templatePath + NotificationType + ".html";

            StreamReader sr = new StreamReader(templatePath.ToLower());
            HTMLData = sr.ReadToEnd();
            sr.Close();

            HTMLData = HTMLData.Replace("{ParticipantName}", ParticipateUserDisplayName);

            SCConnectionStringBuilder connString = new SCConnectionStringBuilder();
            Connection conn = new Connection();
            string k2Server = string.Empty;
            connString.Authenticate = true;
            connString.Host = k2Server;
            connString.Integrated = true;
            connString.IsPrimaryLogin = true;
            connString.Port = 5252;


            SourceCode.Workflow.Client.WorklistCriteria oCrit = new SourceCode.Workflow.Client.WorklistCriteria();
            SourceCode.Workflow.Client.Worklist oWorklist;

            conn.Open(k2Server, connString.ToString());

            conn.ImpersonateUser(ParticipateUserName);
            oWorklist = conn.OpenWorklist(oCrit);



            if (oWorklist.Count > 0)
            {
                for (int i = 0; i < oWorklist.Count; i++)
                {
                    //Open tr
                    tasklisthtml.Append("<tr style='height:15.5pt'>");

                    tasklisthtml.Append("<td width=130 valign=top style='background-color:#ffffff;width:100.25pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt;height:15.5pt'>");
                    tasklisthtml.Append(oWorklist[i].ProcessInstance.Folio);
                    tasklisthtml.Append("</td>");


                    tasklisthtml.Append("<td width=130 valign=top style='background-color:#ffffff;width:100.25pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt;height:15.5pt'>");
                    tasklisthtml.Append(oWorklist[i].ProcessInstance.Name);
                    tasklisthtml.Append("</td>");

                    tasklisthtml.Append("<td width=130 valign=top style='background-color:#ffffff;width:100.25pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt;height:15.5pt'>");
                    tasklisthtml.Append(oWorklist[i].ProcessInstance.StartDate.Date.ToString("dd/MM/yyyy"));
                    tasklisthtml.Append("</td>");


                    tasklisthtml.Append("<td width=130 valign=top style='background-color:#ffffff;width:100.25pt;border:solid windowtext 1.0pt;border-left:none;padding:0in 5.4pt 0in 5.4pt;height:15.5pt'>");
                    tasklisthtml.Append("<a title='Click here' href='" + oWorklist[i].Data + "' target='_blank'>Click here</a>");
                    tasklisthtml.Append("</td>");

                    //Close tr
                    tasklisthtml.Append("</tr>");


                }
                HTMLData = HTMLData.Replace("{AllTasks}", tasklisthtml.ToString());
            }
            else
            {
                HTMLData = string.Empty;

            }

            return HTMLData;
        }

        #endregion


        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigTaskEmailTemplatePath()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string templatePath = appConfig.AppSettings.Settings["TaskEmailTemplatePath"].Value.ToString().Trim();
            return templatePath;
        }

        /// <summary>
        /// Retrieves Application Configuration K2 Server Details
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigK2Server()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string K2ServerName = appConfig.AppSettings.Settings["K2ServerName"].Value.ToString().Trim();
            return K2ServerName;
        }

        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigEmailTemplatePath()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string templatePath = appConfig.AppSettings.Settings["EmailTemplatePath"].Value.ToString().Trim();
            return templatePath;
        }

        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigPlanEmailTemplatePath()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string templatePath = appConfig.AppSettings.Settings["EmailTemplatePath"].Value.ToString().Trim();
            return templatePath;
        }

        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigLeaveEmailTemplatePath()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string templatePath = appConfig.AppSettings.Settings["LeaveEmailTemplatePath"].Value.ToString().Trim();
            return templatePath;
        }

        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigExpenseEmailTemplatePath()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string templatePath = appConfig.AppSettings.Settings["ExpenseEmailTemplatePath"].Value.ToString().Trim();
            return templatePath;
        }


        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigSQLConnectionString()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string ConnectionString = appConfig.AppSettings.Settings["ConnectionString"].Value.ToString().Trim();
            return ConnectionString;
        }

        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigLeaveSQLConnectionString()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string ConnectionString = appConfig.AppSettings.Settings["LeaveConnectionString"].Value.ToString().Trim();
            return ConnectionString;
        }

        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigExpenseSQLConnectionString()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string ConnectionString = appConfig.AppSettings.Settings["ExpenseConnectionString"].Value.ToString().Trim();
            return ConnectionString;
        }
    }
}
