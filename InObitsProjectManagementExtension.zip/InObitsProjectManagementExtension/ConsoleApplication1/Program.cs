﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InObitsProjectManagementExtension;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //string htmldta = InObitsProjectManagementExtension.InObitsProjectManagementExtension.EMailHTMLData("2", "Mohammed Asif M", "IO.ProjectManagementInitiation", "");
            //string htmldta = InObitsProjectManagementExtension.InObitsProjectManagementExtension.LeaveEMailHTMLData("2", "Mohammed Asif M", "LeaveApp.Initiation", "Initialize", "NA");
            string htmldt1a = InObitsProjectManagementExtension.InObitsProjectManagementExtension.GetPendingTasksEmailHTML("K2:DENALLIX\\Jonno", "Mohammed Asif M", "TaskAppPendingTasks");
        }
    }
}
