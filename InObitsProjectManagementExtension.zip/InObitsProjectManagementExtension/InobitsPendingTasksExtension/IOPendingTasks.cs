﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SourceCode.Workflow.Client;
using SourceCode.Workflow.Runtime;
using SourceCode.Hosting.Client.BaseAPI;
using System.Configuration;
using System.Reflection;
using System.IO;

namespace InobitsPendingTasksExtension
{
    public class IOPendingTasks
    {

        #region E-Mail Helper - Get Pending Tasks
        public static string GetPendingTasksEmailHTML(string ParticipateUserName, string ParticipateUserDisplayName, string NotificationType,
            string TaskURL = null
            )
        {
            string templatePath = GetAppConfigTaskEmailTemplatePath();
            string HTMLData = string.Empty;
            templatePath = templatePath + NotificationType + ".html";

            StreamReader sr = new StreamReader(templatePath.ToLower());
            HTMLData = sr.ReadToEnd();
            sr.Close();

            HTMLData = HTMLData.Replace("{ParticipantName}", ParticipateUserName);

            SCConnectionStringBuilder connString = new SCConnectionStringBuilder();
            Connection conn = new Connection();
            string k2Server = string.Empty; 
            connString.Authenticate = true;
            connString.Host = k2Server;
            connString.Integrated = true;
            connString.IsPrimaryLogin = true;
            connString.Port = 5252;


            SourceCode.Workflow.Client.WorklistCriteria oCrit = new SourceCode.Workflow.Client.WorklistCriteria();
            SourceCode.Workflow.Client.Worklist oWorklist;

            conn.Open(k2Server, connString.ToString());

            conn.ImpersonateUser(ParticipateUserName);
            oWorklist = conn.OpenWorklist(oCrit);

            if (oWorklist.Count > 0)
            {
                for(int i=0; i<oWorklist.Count;i++)
                {
                    
                }
            }

            

            return HTMLData;

        }

        #endregion

        /// <summary>
        /// Retrieves the E-Mail template path for the CC notification templates in the App.config
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigTaskEmailTemplatePath()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string templatePath = appConfig.AppSettings.Settings["TaskEmailTemplatePath"].Value.ToString().Trim();
            return templatePath;
        }

        /// <summary>
        /// Retrieves Application Configuration K2 Server Details
        /// </summary>
        /// <returns></returns>
        private static string GetAppConfigK2Server()
        {
            var appConfig = ConfigurationManager.OpenExeConfiguration(Assembly.GetExecutingAssembly().Location);
            string K2ServerName = appConfig.AppSettings.Settings["K2ServerName"].Value.ToString().Trim();
            return K2ServerName;
        }


    }
}
